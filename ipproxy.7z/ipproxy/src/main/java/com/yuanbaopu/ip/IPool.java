package com.yuanbaopu.ip;


public interface IPool {

	IPort getAIP();
	
//	Set<IPort> getIPList();
//	
//	Set<IPort> getUsingIPList();
//	
//	Set<IPort> getForbiddenIPList();
}
