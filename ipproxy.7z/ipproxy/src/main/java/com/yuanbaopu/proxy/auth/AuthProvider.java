package com.yuanbaopu.proxy.auth;


public interface AuthProvider {

	String getAuth();
	
}
